# 2.1 priprema - veličina datoteke
Sav relevantan kod je u datotekama `size.c` i `size_of_size.sh`.

# 2.2 priprema - fork
Sav relevantan kod je u datotekama `fork.c` i `fork_error_rate.py`. Python skripta za određen broj (za broj forkova) radi 20 testiranja te rezultate ispisuje u tekstualnu datoteku. Algoritam možda nije 100% točan u detekciji odstupanja.

