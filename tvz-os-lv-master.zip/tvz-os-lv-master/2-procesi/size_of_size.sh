#!/bin/sh
du -B 1 --apparent-size ./size
# or
#ls -lh size
