sudo insmod sviprocesi.ko
sudo rmmod sviprocesi.ko
dmesg | tail -100
