sudo insmod mojmodul.ko
sudo rmmod mojmodul.ko
dmesg | tail -10
