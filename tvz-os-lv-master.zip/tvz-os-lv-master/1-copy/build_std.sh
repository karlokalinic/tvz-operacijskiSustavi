clang -DLIB_STD cp.c -o cp_std
