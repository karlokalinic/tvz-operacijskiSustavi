clang -DLIB_SYS cp.c -o cp_sys
