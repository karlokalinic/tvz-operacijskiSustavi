clang zad-1.c -o zad-1 && ./zad-1 $1 && rm ./zad-1
