clang -pthread zad-4.c -o zad-4 && ./zad-4 && rm ./zad-4
