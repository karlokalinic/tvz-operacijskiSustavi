clang -pthread zad-2.c -o zad-2 && ./zad-2 $1 && rm ./zad-2
