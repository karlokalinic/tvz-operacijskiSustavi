clang -pthread zad-1.c -o zad-1 && bash -c "time ./zad-1" && rm ./zad-1
