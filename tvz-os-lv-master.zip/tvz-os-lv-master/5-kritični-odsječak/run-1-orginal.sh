clang -pthread zad-1-orginal.c -o zad-1-orginal && bash -c "time ./zad-1-orginal" && rm ./zad-1-orginal
